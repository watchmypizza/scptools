// JavaScript file (script.js)
const backbtn = document.getElementById('backbtn');

// Use 'click' as a string for the event type and 'function' for the callback
backbtn.addEventListener('click', function() {
    window.location.href = "../recipegen.html";
});
